Bomberman 64

This model was ripped an put together by Adrian Garcia.

Property of Hudson Soft and Nintendo.

Programs used : Ninja Ripper, Blender

Note: Many parts of Bomberman 64 are flat plains that follow the camera to create the illusion of 3d. For this model I took some liberties and replaced a few of these objects with actual 3d elements. This means the models may be slightly altered from the originals, but all the textures remain intact in case you want to have it closer to the original model.

Links to Adrian Garcia's art pages:
https://www.instagram.com/adrian_garcia_art/
https://www.artstation.com/adrianagegarcia
https://www.youtube.com/channel/UCozWFQJYqQdxwIruvzpAg7A/
https://www.facebook.com/AgeGarciaArt/