=== Model's Resource ===
Platform : Nintendo DS
Game     : Final Fantasy III
Model    : NPC/Chocobo
========================

Contents:
- DAE COLLADA Model(s) (with animations)
- FBX Autodesk Model(s) (with animations)
- PNG Texture files (with alpha channels)

Ripped by Lexou Duck, using Apicula and Tinke

For more info on how to properly import these models into your 3D program, check out:
https://github.com/scurest/apicula/wiki/IMPORT:-Blender
https://github.com/scurest/apicula/wiki/IMPORT:-Maya
https://github.com/LexouDuck/MayaUtilities

More general info on Nintendo DS 3D Models and apicula here:
https://github.com/scurest/apicula/wiki

Tue, Mar 10, 2020  4:42:37 AM
